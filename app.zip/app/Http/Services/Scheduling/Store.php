<?php

namespace App\Http\Services\Scheduling;

use App\Http\Requests\Scheduling\StoreSchedulingRequest;
use App\Http\Services\ServiceBase;


class Store extends ServiceBase
{
    public function execute(StoreSchedulingRequest $request)
    {

    }
}
