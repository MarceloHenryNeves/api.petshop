<?php

namespace App\Http\Services\Services;

class AbstractServices
{

}
