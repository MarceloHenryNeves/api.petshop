# api.petshop
Desenvolvimento da API de Petshop deselvolvido em Laravel: Criação da API de Petshop em Laravel com ênfase em boas práticas e Arquitetura robusta para melhor atender às necessidades do Petshop.
