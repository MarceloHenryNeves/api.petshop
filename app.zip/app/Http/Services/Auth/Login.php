<?php

namespace App\Http\Services\Auth;

use App\Http\Repositories\UserRepository;
use App\Http\Requests\Auth\LoginRequest;
use App\Http\Responses\ApiErrorResponse;
use App\Http\Services\ServiceBase;

class Login extends ServiceBase
{

    public function execute(LoginRequest $request, UserRepository $userRepository)
    {
        $requestValidated = (object)$request->validated();

        $token = auth()->attempt([
            "clientId" => $this->hashClientId($requestValidated->email . '|' . getenv('APPLICATION_TOKEN')),
            "password" => $requestValidated->password
        ]);

        if (!$token) {
            return new ApiErrorResponse('Unauthorized', 401);
        }


        $data['name'] = $this->decrypt(auth()->user()->name);
        $data['cpf'] = $this->decrypt(auth()->user()->cpf);
        $data['email'] = $this->decrypt(auth()->user()->email);
        $data['phone'] = $this->decrypt(auth()->user()->phone);
        $data['pets'] = $userRepository->pets();

        return $this->respondWithToken(array_merge($data, ['token' => $token]));
    }
}
